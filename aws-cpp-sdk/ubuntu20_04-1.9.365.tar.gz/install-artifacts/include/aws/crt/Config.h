#pragma once
/**
 * Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
 * SPDX-License-Identifier: Apache-2.0.
 */

#define AWS_CRT_CPP_VERSION "0.18.16"
#define AWS_CRT_CPP_VERSION_MAJOR 0
#define AWS_CRT_CPP_VERSION_MINOR 18
#define AWS_CRT_CPP_VERSION_PATCH 16
#define AWS_CRT_CPP_GIT_HASH "0a9e0ad7ab07113c65b4846ece3a386407c9c0d3"
